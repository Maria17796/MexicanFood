import PageHome from "./page-home.js";
import PageLogin from "./page-login.js";
import PageRegister from "./page-register.js";
import Toolbar from "../component/toolbar/toolbar.js";
import ToolbarAdmin from "../component/toolbar/toolbarAdmin.js"; 

export default class Application {
  #apiUrl = "http://localhost:49007/api";
  header = null;
  #footer = null;
  #benutzer = null;
  toolbar = null;

  constructor() {
    const header = document.querySelector("header");
    const main = document.querySelector("main");

    this.toolbar = new Toolbar({args:this,target:header,benutzer:null});
    const toolbarData = sessionStorage.getItem('rolle');
    if (toolbarData) {
      const toolbarOptions = JSON.parse(toolbarData);
      if(toolbarOptions === 1)
        this.toolbar = new ToolbarAdmin({args:this,target:header,benutzer:toolbarOptions});
    }

    //====================================================
    window.addEventListener("hashchange", (e) => {
      this.#navigate(location.hash);
    });
    //this.#navigate(location.hash);
    // this.apiGet(
    //   (r) => {
    //     if (r.success) {
    //       this.benutzer = r.options;
    //       this.#navigate(location.hash);
    //     } else {

    //       this.#navigate("#start");
    //     }
    //   },
    //   (ex) => {

    //     this.#navigate("#start");
    //   },
    //   "/page",
    //   "init",
    //   null
    // );
  } //constructor

  #navigate(queryString) {
	console.log(queryString);
	const main = document.querySelector('main');
	let navTarget = '';
	let args = {
		target: main,
		app: this
	};

let hashParts = queryString.split("?");
if (hashParts.length > 1) {
  navTarget = hashParts[0].substr(1);
  let usp = new URLSearchParams(hashParts[1]);
  for (const [key, value] of usp) {
	args[key] = value;
  }
} 
	else navTarget = queryString.substr(1);

    main.innerHTML = "";
    switch (navTarget) {
      case "login":
        new PageLogin(args);
        break;
      case "register":
        new PageRegister(args);
        break;
      default:
        new PageHome(args);
        break;
    }
  }

  apiLogin(successCallback, errorCallback, loginData) {
    fetch(this.#apiUrl + "/person/login", {
      credentials: "include",
      method: "POST",
      body: loginData,
      cache: "no-cache",
    })
      .then((r) => {
        console.log(r);
        if (r.status == 200) {
          // Wandelt den JSON-String in ein JavaScript-Objekt um
          return r.json();
        }
        else throw new Error(r.status + " " + r.statusText);
      })
      .then(successCallback)

      .catch(errorCallback);
  }

   apiRegister(successCallback, errorCallback, registerData){
   fetch(this.#apiUrl + "/person/register", {
    credentials: "include",
    method: "POST",
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(registerData),
    cache: "no-cache",
  })
    .then((r) => {
      console.log(r);
      if (r.status == 200) return r.json();
      else throw new Error(r.status + " " + r.statusText);
    })
    .then(successCallback)

    .catch(errorCallback);
}


  apiGetList(successCallback, errorCallback, url, args) {
    let completeUrl = this.#apiUrl + url;
    if (args) {
      let i = 0;
      for (let arg in args) {
        completeUrl += (i == 0 ? "?" : "&") + arg + "=" + args[arg];
        i++;
      }
    }

    fetch(completeUrl, {
      credentials: "include",
      cache: "no-cache",
    })
      .then((r) => {
        if (r.status == 200) return r.json();
        else if (r.status == 401) window.open("#logout", "_self");
        else throw new Error(r.status + " " + r.statusText);
      })
      .then(successCallback)
      .catch(errorCallback);
  }

  apiGet(successCallback, errorCallback, url, id, args) {
    let completeUrl = this.#apiUrl + url + "/" + id;
    if (args) {
      let i = 0;
      for (let arg in args) {
        completeUrl += (i == 0 ? "?" : "&") + arg + "=" + args[arg];
        i++;
      }
    }

    fetch(completeUrl, {
      credentials: "include",
      cache: "no-cache",
    })
      .then((r) => {
        if (r.status == 200) return r.json();
        else if (r.status == 401) window.open("#logout", "_self");
        else throw new Error(r.status + " " + r.statusText);
      })
      .then(successCallback)
      .catch(errorCallback);
  }

  apiSet(successCallback, errorCallback, url, id, daten) {
    fetch(this.#apiUrl + url + (id ? "/" + id : ""), {
      credentials: "include",
      method: id ? "PUT" : "POST",
      body: JSON.stringify(daten),
      cache: "no-cache",
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((r) => {
        if (r.status == 200) return r.json();
        else if (r.status == 401) window.open("#logout", "_self");
        else throw new Error(r.status + " " + r.statusText);
      })
      .then(successCallback)
      .catch(errorCallback);
  }

  apiArtikelDateiUpload(successCallback, errorCallback, id, files) {
    let formData = new FormData();
    for (let idx = 0; idx < files.length; idx++) {
      formData.append("f" + idx, files[idx], files[idx].name);
    }

    fetch(this.#apiUrl + "/artikel/" + id + "/datei", {
      credentials: "include",
      method: "POST",
      body: formData,
      cache: "no-cache",
    })
      .then((r) => {
        if (r.status == 200) return r.json();
        else if (r.status == 401) window.open("#logout", "_self");
        else throw new Error(r.status + " " + r.statusText);
      })
      .then(successCallback)
      .catch(errorCallback);
  }

  apiDelete(successCallback, errorCallback, url, id) {
    if (!id) errorCallback("ID fehlt!!!");
    else {
      fetch(this.#apiUrl + url + "/" + id, {
        credentials: "include",
        method: "DELETE",
        cache: "no-cache",
      })
        .then((r) => {
          if (r.status == 200) return r.json();
          else if (r.status == 401) window.open("#logout", "_self");
          else throw new Error(r.status + " " + r.statusText);
        })
        .then(successCallback)
        .catch(errorCallback);
    }
  }
}
