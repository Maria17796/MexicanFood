export default class PageHome{

constructor(args) {
    fetch('./src/page-home.html').then( (r) => {
        if (r.status == 200) return r.text();
        else throw new Error (r.status + ' ' + r.statusText);
    }).then( (html) => {
        args.target.innerHTML = html;
    }).catch( (ex) => {
        args.target.innerHTML = '<div class="alert alert-danger" role="alert">Fehler: ' + ex + '</div>';
    });
}

}//class