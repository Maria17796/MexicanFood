import Application from "./app.js"

new Application();